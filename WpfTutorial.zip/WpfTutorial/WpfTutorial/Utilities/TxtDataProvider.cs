﻿using System;
using System.IO;
using System.Windows.Data;


namespace WpfTutorial.Utilities
{
    public class TxtDataProvider : DataSourceProvider
    {
        public string Uri { get; set; }

        protected override void BeginQuery()
        {
            try
            {
                OnQueryFinished(File.ReadAllText(Uri), null, null, null);
            }
            catch (Exception e)
            {
                OnQueryFinished(null, e, null, null);
            }
        }
    }
}
