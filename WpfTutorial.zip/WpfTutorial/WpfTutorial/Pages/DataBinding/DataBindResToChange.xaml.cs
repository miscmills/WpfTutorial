﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfTutorial.Utilities;
namespace WpfTutorial.Pages.DataBinding
{
    /// <summary>
    /// Interaction logic for DataBindResToChange.xaml
    /// </summary>
    public partial class DataBindResToChange : Page
    {
        // Create list for example
        private List<UserBroke> users = new List<UserBroke>();

        public DataBindResToChange()
        {
            InitializeComponent();
            this.DataContext = this;

            // Add new users
            users.Add(new UserBroke() { Name = "John Doe" });
            users.Add(new UserBroke() { Name = "Jane Doe" });

            // Assign users
            lbUsers.ItemsSource = users;
        }

        // Add user action
        private void btnAddUser_Click(object sender, RoutedEventArgs e)
        {
            users.Add(new UserBroke() { Name = "New user" });
        }

        // Change user action
        private void btnChangeUser_Click(object sender, RoutedEventArgs e)
        {
            if (lbUsers.SelectedItem != null)
                (lbUsers.SelectedItem as UserBroke).Name = "Random Name";
        }

        // Delete user action
        private void btnDeleteUser_Click(object sender, RoutedEventArgs e)
        {
            if (lbUsers.SelectedItem != null)
                users.Remove(lbUsers.SelectedItem as UserBroke);
        }
    }
}
