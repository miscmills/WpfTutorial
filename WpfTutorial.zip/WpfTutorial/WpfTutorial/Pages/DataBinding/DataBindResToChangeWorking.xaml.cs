﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using WpfTutorial.Utilities;

namespace WpfTutorial.Pages.DataBinding
{
    /// <summary>
    /// Interaction logic for DataBindResToChangeWorking.xaml
    /// </summary>
    public partial class DataBindResToChangeWorking : Page
    {
        // Build list for examples needing user data
        private ObservableCollection<User> users = new ObservableCollection<User>();

        public DataBindResToChangeWorking()
        {
            InitializeComponent();
            this.DataContext = this;

            // Add users for example
            users.Add(new User() { Name = "John Doe" });
            users.Add(new User() { Name = "Jane Doe" });

            // Assign users to list for example
            lbUsers.ItemsSource = users;
        }

        // Add user action
        private void btnAddUser_Click(object sender, RoutedEventArgs e)
        {
            users.Add(new User() { Name = "New user" });
        }

        // Change user action
        private void btnChangeUser_Click(object sender, RoutedEventArgs e)
        {
            if (lbUsers.SelectedItem != null)
                (lbUsers.SelectedItem as User).Name = "Random Name";
        }

        // Delete user action
        private void btnDeleteUser_Click(object sender, RoutedEventArgs e)
        {
            if (lbUsers.SelectedItem != null)
                users.Remove(lbUsers.SelectedItem as User);
        }
    }
}
