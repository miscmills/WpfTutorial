﻿using System.Windows.Controls;

namespace WpfTutorial.Pages.BasicControls
{
    /// <summary>
    /// Interaction logic for TextBlockCtrlInlineFormatting.xaml
    /// </summary>
    public partial class TextBlockCtrlInlineFormatting : Page
    {
        public TextBlockCtrlInlineFormatting()
        {
            InitializeComponent();
            this.DataContext = this;
        }
    }
}
