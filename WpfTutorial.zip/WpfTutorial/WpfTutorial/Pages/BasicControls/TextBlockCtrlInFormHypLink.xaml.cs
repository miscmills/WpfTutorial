﻿using System.Windows;
using System.Windows.Controls;
using WpfTutorial.SubWindows;

namespace WpfTutorial.Pages.BasicControls
{
    /// <summary>
    /// Interaction logic for TextBlockCtrlInFormHypLink.xaml
    /// </summary>
    public partial class TextBlockCtrlInFormHypLink : Page
    {
        public TextBlockCtrlInFormHypLink()
        {
            InitializeComponent();
            this.DataContext = this;
        }

        private void TextBlockCtrlHypLinkExample_Click(object sender, RoutedEventArgs e)
        {
            TextBlockCtrlHyperlinkSample exampleWindow = new TextBlockCtrlHyperlinkSample();
            exampleWindow.Show();
        }        
    }
}
