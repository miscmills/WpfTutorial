﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfTutorial.Pages.CommonInterfaceCtrls
{
    /// <summary>
    /// Interaction logic for ComIfCtrlsStatusBar.xaml
    /// </summary>
    public partial class ComIfCtrlsStatusBar : Page
    {
        public ComIfCtrlsStatusBar()
        {
            InitializeComponent();
            this.DataContext = this;
        }

        private void txtEditor_SelectionChanged(object sender, RoutedEventArgs e)
        {

            int row = txtEditor.GetLineIndexFromCharacterIndex(txtEditor.CaretIndex);
            int col = txtEditor.CaretIndex - txtEditor.GetCharacterIndexFromLineIndex(row);
            lblCursorPosition.Text = "Line " + (row + 1) + ", Char " + (col + 1);
        }
        private void txtEditor_SelectionChangedExTwo(object sender, RoutedEventArgs e)
        {
            int row = txtEditorTwo.GetLineIndexFromCharacterIndex(txtEditorTwo.CaretIndex);
            int col = txtEditorTwo.CaretIndex - txtEditorTwo.GetCharacterIndexFromLineIndex(row);
            lblCursorPositionTwo.Text = "Line " + (row + 1) + ", Char " + (col + 1);
        }
    }
}
