﻿using System.Windows.Controls;

namespace WpfTutorial.Pages.GetStarted
{
    /// <summary>
    /// Interaction logic for GetStartedHelloWpf.xaml
    /// </summary>
    public partial class GetStartedHelloWpf : Page
    {
        public GetStartedHelloWpf()
        {
            InitializeComponent();
        }
    }
}
