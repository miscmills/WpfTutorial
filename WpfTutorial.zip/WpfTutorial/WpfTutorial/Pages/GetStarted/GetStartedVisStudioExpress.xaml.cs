﻿using System.Windows;
using System.Windows.Controls;
using WpfTutorial.SubWindows;
namespace WpfTutorial.Pages.GetStarted
{
    /// <summary>
    /// Interaction logic for GetStartedVisStudioExpress.xaml
    /// </summary>
    public partial class GetStartedVisStudioExpress : Page
    {
        public GetStartedVisStudioExpress()
        {
            InitializeComponent();
        }
    }
}
