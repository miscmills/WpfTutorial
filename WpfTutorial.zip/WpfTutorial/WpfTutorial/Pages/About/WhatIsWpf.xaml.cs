﻿using System.Windows.Controls;

namespace WpfTutorial.Pages.About
{
    /// <summary>
    /// Interaction logic for WhatIsWpf.xaml
    /// </summary>
    public partial class WhatIsWpf : Page
    {
        public WhatIsWpf()
        {
            InitializeComponent();
        }
    }
}
