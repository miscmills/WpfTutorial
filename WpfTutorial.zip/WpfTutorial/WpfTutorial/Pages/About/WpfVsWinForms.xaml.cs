﻿using System.Windows.Controls;

namespace WpfTutorial.Pages.About
{
    /// <summary>
    /// Interaction logic for WpfVsWinForms.xaml
    /// </summary>
    public partial class WpfVsWinForms : Page
    {
        public WpfVsWinForms()
        {
            InitializeComponent();
        }
    }
}
