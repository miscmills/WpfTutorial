﻿using System.Windows.Controls;

namespace WpfTutorial.Pages.SectionXaml
{
    /// <summary>
    /// Interaction logic for XamlAbout.xaml
    /// </summary>
    public partial class XamlAbout : Page
    {
        public XamlAbout()
        {
            InitializeComponent();
        }
    }
}
