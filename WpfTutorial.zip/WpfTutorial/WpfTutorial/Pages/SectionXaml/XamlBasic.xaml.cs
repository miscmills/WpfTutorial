﻿using System.Windows.Controls;

namespace WpfTutorial.Pages.SectionXaml
{
    /// <summary>
    /// Interaction logic for XamlBasic.xaml
    /// </summary>
    public partial class XamlBasic : Page
    {
        public XamlBasic()
        {
            InitializeComponent();
        }
    }
}
