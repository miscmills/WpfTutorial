﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace WpfTutorial.Pages.SectionXaml
{
    /// <summary>
    /// Interaction logic for XamlEvents.xaml
    /// </summary>
    public partial class XamlEvents : Page
    {
        public XamlEvents()
        {
            InitializeComponent();
        }

        private void pnlMainStack_MouseUp(object sender, MouseButtonEventArgs e)
        {
            MessageBox.Show("You clicked me at " + e.GetPosition(this).ToString());
        }
    }
}
