﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace WpfTutorial.Pages.SectionXaml
{
    /// <summary>
    /// Interaction logic for XamlVsCode.xaml
    /// </summary>
    public partial class XamlVsCode : Page
    {
        public XamlVsCode()
        {
            InitializeComponent();
            Button btn = new Button();
            btn.FontWeight = FontWeights.Bold;

            WrapPanel pnl = new WrapPanel();

            TextBlock txt = new TextBlock();
            txt.Text = "Multi";
            txt.Foreground = Brushes.Blue;
            txt.Padding = new Thickness(0);
            pnl.Children.Add(txt);

            txt = new TextBlock();
            txt.Text = "Color";
            txt.Foreground = Brushes.Red;
            txt.Padding = new Thickness(0);
            pnl.Children.Add(txt);

            txt = new TextBlock();
            txt.Text = "Button";
            txt.Padding = new Thickness(0);
            pnl.Children.Add(txt);

            btn.Content = pnl;
            pnlMainStack.Children.Add(btn);
        }
    }
}
