﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfTutorial.SubWindows;

namespace WpfTutorial.Pages.MiscControls
{
    /// <summary>
    /// Interaction logic for MiscCtrlsProgressBar.xaml
    /// </summary>
    public partial class MiscCtrlsProgressBar : Page
    {
        public MiscCtrlsProgressBar()
        {
            InitializeComponent();
            this.DataContext = this;
        }

        private void ProgBarExampleOne_Click(object sender, RoutedEventArgs e)
        {
            MiscCtrlProgBarExampleOne exampleWindow = new MiscCtrlProgBarExampleOne();
            exampleWindow.Show();
        }
        private void ProgBarExampleTwo_Click(object sender, RoutedEventArgs e)
        {
            MiscCtrlProgBarExampleTwo exampleWindow = new MiscCtrlProgBarExampleTwo();
            exampleWindow.Show();
        }
    }
}
