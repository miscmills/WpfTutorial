﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfTutorial.SubWindows;

namespace WpfTutorial.Pages.Panels
{
    /// <summary>
    /// Interaction logic for PnlsWrapPanel.xaml
    /// </summary>
    public partial class PnlsWrapPanel : Page
    {
        public PnlsWrapPanel()
        {
            InitializeComponent();
            this.DataContext = this;
        }

        private void PnlsWrapPanelExample_Click(object sender, RoutedEventArgs e)
        {
            PnlsWrapPanelExample exampleWindow = new PnlsWrapPanelExample();
            exampleWindow.Show();
        }

        private void PnlsWrapPanelVertExample_Click(object sender, RoutedEventArgs e)
        {
            PnlsWrapPanelVertExample exampleWindow = new PnlsWrapPanelVertExample();
            exampleWindow.Show();
        }

        private void PnlsWrapPanelBtnExample_Click(object sender, RoutedEventArgs e)
        {
            PnlsWrapPanelBtnExample exampleWindow = new PnlsWrapPanelBtnExample();
            exampleWindow.Show();
        }        
    }
}
