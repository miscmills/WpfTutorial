﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfTutorial.SubWindows
{
    /// <summary>
    /// Interaction logic for MiscCtrlProgBarExampleOne.xaml
    /// </summary>
    public partial class MiscCtrlProgBarExampleOne : Window
    {
        public MiscCtrlProgBarExampleOne()
        {
            InitializeComponent();
        }

        private void Window_ContentRendered(object sender, EventArgs e)
        {
            for (int i = 0; i < 100; i++)
            {
                pbStatus.Value++;
                Thread.Sleep(100);
            }
        }
    }
}
